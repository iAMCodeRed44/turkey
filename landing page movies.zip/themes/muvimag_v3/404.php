<?php
/*
| -------------------------------------------------------------------------------
| Author            : Mathin Mochammad
| Template Name     : Muvimag V2
| -------------------------------------------------------------------------------
*/
include('header.php'); ?>

      <div class="well text-center">
        <h1>This is somewhat embarrassing, isn’t it?</h1>
        <p class="lead">It seems we can’t find what you’re looking for. Perhaps searching can help.</p>
      </div>

<?php include('footer.php'); ?>