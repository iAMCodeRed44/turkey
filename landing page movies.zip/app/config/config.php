<?php
$oc_config = array (
    
    //================================================================================================
   

    "favicon"         => "favicon.gif" ,

    //================================================================================================

    "sitelogo"        => "Watch Movies & TV Series Full HD",
    
    "sitename"        => "Watch Full Movies & TV Series in HD Quality",

    "sitedescription" => "Watch Full Movies Streaming HD Quality and Full Episode TV Shows for FREE",

    "sitekeywords"    => "full movie, full episode",

    "sitethemes"      => "muvimag_v3",

    "offer_link1"     => "//ads.affbuzzads.com/redirect?ref=171574&ad_unit=64",

    "offer_link2"     => "//ads.affbuzzads.com/redirect?ref=171574&ad_unit=64",

    // "sport_offer"     => "",        // Jika Belum Di Include Plugin Sport nya gak bisa di gunakan

    "histatsID"       => "4010383",

    //================================================================================================

    "tvdb_search"     => "true",

    "cache"           => "true",

    "_seo"            => "true",

    "_stt"            => "true",

    "protect_content" => "false",       // disable klik kanan, block text, copy paste pada halaman LP

    "search_url"      => "search",

    "url_end"         => ".html",
    
    "category_url"    => "genre",
    
    "timezone"        => "Asia/Jakarta",

    "debug"           => "true",

);

$alt_country2 = array(
    /*
    |--------------------------------------------------------------------------
    | Contoh Penulisan Country Code
    |--------------------------------------------------------------------------
    | 'US', 'GB', 'UK'
    | Contoh Dibawah Menandakan Negara ID (Indonesia) dan MY (Malaysia) 
    | Offer Link nya akan di redirect ke Offer Kedua
    |
    */
   
   'ID', 'MY', 'MX', 'RU'
);